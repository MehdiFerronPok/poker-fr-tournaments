"""API package init."""

from .main import app  # noqa: F401