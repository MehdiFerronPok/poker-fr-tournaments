"""Ingestion module initializer."""

from .rss_ingestor import RssIngestor  # noqa: F401
from .html_ingestor import HtmlIngestor  # noqa: F401