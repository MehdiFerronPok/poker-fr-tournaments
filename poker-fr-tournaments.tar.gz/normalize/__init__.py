"""Normalization package initialisation."""

from .normalizer import normalize_and_upsert  # noqa: F401